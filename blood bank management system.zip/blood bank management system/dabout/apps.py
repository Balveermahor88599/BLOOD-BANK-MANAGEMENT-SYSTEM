from django.apps import AppConfig


class DaboutConfig(AppConfig):
    name = 'dabout'
